# EnergiaClara AI — resumo da análise

**Objetivo:** orientar consumidores residenciais sobre eficiência LED e geração solar no mesmo período de referência.
**Ambiente:** Python no Google Colab, com gráficos e assistente baseado em regras.

- Período: 30 dias.
- Consumo residencial utilizado: 250.00 kWh no período.
- Tarifa inserida: R$ 0.9000/kWh (valor ilustrativo, não fatura).
- Economia física com LED: 76.50 kWh no período.
- Geração FV estimada: 108.69 kWh no período, com HSP=4.53.
- Origem efetiva da HSP: NASA POWER, climatologia histórica da irradiação horizontal — São Paulo (SP).
- Fator financeiro solar: 75%, **hipótese didática**.
- Participantes com relatos reais registrados: 1.
- Situação do teste e melhoria: TESTE REAL REGISTRADO — RETESTE OPCIONAL.

**Limites:** o simulador não calcula a conta regulatória real, compensação de créditos, tributos, custo mínimo, sazonalidade, sombreamento, degradação, ciclo de vida ou financiamentos.
**Fontes e hipóteses:** ver `rastreabilidade_parametros.csv`, `ficha_procedencia_dados.csv` e `referencias_metodologicas.csv`.
**Testes automatizados:** ver `testes_assistente.csv`, `testes_regressao.csv` e `testes_formatacao.csv`.
